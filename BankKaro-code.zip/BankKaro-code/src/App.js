import React from "react";
import "./App.css";
import RouterFile from "./route/router";

function App() {

  return (
    <>
     <RouterFile/>
    </>
  );
}

export default App;
